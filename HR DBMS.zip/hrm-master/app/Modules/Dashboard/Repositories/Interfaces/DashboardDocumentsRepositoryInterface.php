<?php

namespace App\Modules\Dashboard\Repositories\Interfaces;

interface DashboardDocumentsRepositoryInterface
{
}
