<?php

namespace App\Modules\Discipline\Repositories\Interfaces;

interface DisciplinaryCaseRepositoryInterface
{
}
