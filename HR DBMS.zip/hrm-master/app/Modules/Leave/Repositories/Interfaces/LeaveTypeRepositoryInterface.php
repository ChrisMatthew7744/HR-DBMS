<?php

namespace App\Modules\Leave\Repositories\Interfaces;

interface LeaveTypeRepositoryInterface
{
}
