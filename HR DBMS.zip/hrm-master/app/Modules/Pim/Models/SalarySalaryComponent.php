<?php

namespace App\Modules\Pim\Models;

use Illuminate\Database\Eloquent\Model;

class SalarySalaryComponent extends Model
{
    protected $table = 'salaries_salary_components';
    protected $guarded = ['id'];
}
