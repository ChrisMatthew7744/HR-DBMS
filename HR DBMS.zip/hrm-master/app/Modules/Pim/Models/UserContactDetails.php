<?php

namespace App\Modules\Pim\Models;

use Illuminate\Database\Eloquent\Model;

class UserContactDetails extends Model
{
    protected $table = 'user_contact_details';
    protected $guarded = ['id'];
}
