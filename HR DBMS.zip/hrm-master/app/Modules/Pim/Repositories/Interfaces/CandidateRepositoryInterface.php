<?php

namespace App\Modules\Pim\Repositories\Interfaces;

interface CandidateRepositoryInterface
{
}
