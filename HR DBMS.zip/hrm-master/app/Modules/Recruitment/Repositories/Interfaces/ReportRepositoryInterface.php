<?php

namespace App\Modules\Recruitment\Repositories\Interfaces;

interface ReportRepositoryInterface
{
}
