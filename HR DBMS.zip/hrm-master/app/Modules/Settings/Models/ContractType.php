<?php

namespace App\Modules\Settings\Models;

use Illuminate\Database\Eloquent\Model;

class ContractType extends Model
{
    protected $table = 'contract_types';
    protected $guarded = ['id'];
}
