<?php

namespace App\Modules\Settings\Models;

use Illuminate\Database\Eloquent\Model;

class EducationInstitution extends Model
{
    protected $table = 'education_institutions';
    protected $guarded = ['id'];
}
