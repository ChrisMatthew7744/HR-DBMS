<?php

namespace App\Modules\Settings\Models;

use Illuminate\Database\Eloquent\Model;

class Skill extends Model
{
    protected $table = 'skills';
    protected $guarded = ['id'];
}
