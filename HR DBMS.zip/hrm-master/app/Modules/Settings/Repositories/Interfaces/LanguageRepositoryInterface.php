<?php

namespace App\Modules\Settings\Repositories\Interfaces;

interface LanguageRepositoryInterface
{
}
