<?php

namespace App\Modules\Time\Repositories\Interfaces;

interface ProjectRepositoryInterface
{
}
