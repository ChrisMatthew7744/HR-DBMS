<?php
return array(

    /*
    |--------------------------------------------------------------------------
    | Default Table Id
    |--------------------------------------------------------------------------
    |
    | The default table id if none is set through the ->id() method on the view
    |
    | Supported: string
    |
    */
    'defaultTableId' => 'dataTable'

);