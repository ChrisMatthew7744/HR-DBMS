<html>
<head></head>
<body>
{!!trans('emails.employee_login.body', $email)!!}
</body>
</html>
